package com.example.githubuser.data

data class UserRespons(
    val items : ArrayList<User>
)
