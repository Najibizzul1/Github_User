package com.example.githubuser.ui

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.githubuser.api.RetrofitClient
import com.example.githubuser.data.User
import com.example.githubuser.data.UserRespons
import com.example.githubuser.data.local.SettingPrefences
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel(private val prefences: SettingPrefences) : ViewModel(){

    private val listUsers = MutableLiveData<ArrayList<User>>()

    fun getTheme() = prefences.getThemeSetting().asLiveData()

    fun getSearchUsers(): LiveData<ArrayList<User>>{
        return listUsers
    }

    fun setSearchUsers(query: String){
        RetrofitClient.apiInstance
            .getSearchUsers(query)
            .enqueue(object : Callback<UserRespons>{
                override fun onResponse(
                    call: Call<UserRespons>,
                    response: Response<UserRespons>
                ) {
                    if (response.isSuccessful){
                        listUsers.postValue(response.body()?.items)
                    }
                }

                override fun onFailure(call: Call<UserRespons>, t: Throwable) {
                    Log.d("Network Failure", t.message!!)
                }

            })
        class Factory(private val prefences: SettingPrefences)
            : ViewModelProvider.NewInstanceFactory(){

            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                MainViewModel(prefences) as T
            }
    }
}

