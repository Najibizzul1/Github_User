package com.example.githubuser.data

data class User(
    val username: String,
    val avatar_url: String,
    val login: String,
    val id: Int
)
