package com.example.githubuser.ui.Favorite

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.githubuser.data.local.FavoriteUser
import com.example.githubuser.data.local.FavoriteUserDAO
import com.example.githubuser.data.local.UserDatabase

class FavoriteViewModel(application: Application)
    : AndroidViewModel(application){
    private var userDAO: FavoriteUserDAO?
    private var userDb: UserDatabase?

    init {
        userDb = UserDatabase.getDatabase(application)
        userDAO = userDb?.favoriteUserDAO()
    }

    fun getFavoriteUser(): LiveData<List<FavoriteUser>>? {
        return userDAO?.getFavoriteUser()
    }
}