package com.example.githubuser.ui.Favorite

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuser.R
import com.example.githubuser.data.User
import com.example.githubuser.data.local.FavoriteUser
import com.example.githubuser.databinding.ActivityFavoriteBinding
import com.example.githubuser.ui.DetailUserActivity
import com.example.githubuser.ui.MainAdapter

class FavoriteActivity : AppCompatActivity() {

    private lateinit var binding : ActivityFavoriteBinding
    private lateinit var adapter : MainAdapter
    private lateinit var viewModel: FavoriteViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = MainAdapter()
        adapter.notifyDataSetChanged()

        viewModel = ViewModelProvider(this)
            .get(FavoriteViewModel::class.java)

        adapter.setOnItemClickCallBack(object : MainAdapter.OnItemClickCallBack {
            override fun onItemClicked(data: User) {
                navigateToDetailUser(data.login, data.id, data.avatar_url)
            }
        })


        viewModel.getFavoriteUser()?.observe(this, {
            if (it!=null){
                val list = mapList(it)
                adapter.setList(list)
                setupRecyclerView()
            }
        })
    }
    private fun setupRecyclerView() {
        binding.rv_userFavorite.layoutManager = LinearLayoutManager(this)
        binding.rv_userFavorite.setHasFixedSize(true)
        binding.rv_userFavorite.adapter = adapter
    }

    private fun mapList(users: List<FavoriteUser>): ArrayList<User> {
        val listUsers = ArrayList<User>()
        for (user in users){
            val userMapped = User(
                user.login,
                user.id,
                user.avatar_url
            )
            listUsers.add(userMapped)
        }
        return listUsers
    }
    private fun navigateToDetailUser(username: String, id: Int, avatar_url: String) {
        val intent = Intent(this@FavoriteActivity, DetailUserActivity::class.java)
        intent.putExtra(DetailUserActivity.EXTRA_USERNAME, username)
        intent.putExtra(DetailUserActivity.EXTRA_ID, id.toString())
        intent.putExtra(DetailUserActivity.EXTRA_URL, avatar_url)
        startActivity(intent)
    }
}